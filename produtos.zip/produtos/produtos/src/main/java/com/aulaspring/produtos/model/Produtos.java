package com.aulaspring.produtos.model;

import jakarta.persistence.*;

import java.math.BigDecimal;

@Entity
@Table(name ="produtos")
public class Produtos {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id_produto;
    @Column(name = "nome_produto")
    private String nome_produto;
    @Column(name = "preco")
    private BigDecimal preco;
    @Column(name = "tipo")
    private String tipo;
    @Column(name = "quant_estoque")
    private int quant_estoque;
    @Column(name = "descricao")
    private String descricao;

    public Integer getId_produto() {
        return id_produto;
    }

    public void setId_produto(Integer id_produto) {
        this.id_produto = id_produto;
    }

    public String getNome_produto() {
        return nome_produto;
    }

    public void setNome_produto(String nome_produto) {
        this.nome_produto = nome_produto;
    }

    public BigDecimal getPreco() {
        return preco;
    }

    public void setPreco(BigDecimal preco) {
        this.preco = preco;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getQuant_estoque() {
        return quant_estoque;
    }

    public void setQuant_estoque(int quant_estoque) {
        this.quant_estoque = quant_estoque;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
