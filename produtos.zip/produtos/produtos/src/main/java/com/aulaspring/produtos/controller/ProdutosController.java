package com.aulaspring.produtos.controller;

import com.aulaspring.produtos.model.Produtos;
import com.aulaspring.produtos.repository.ProdutosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/produtos")
public class ProdutosController {

    @Autowired
    ProdutosRepository repository;

    @PostMapping
    public void salvarProduto(@PathVariable Produtos produtos){
        repository.save(produtos);
    }

    @GetMapping
    public List<Produtos> pegarProdutos(){
        return repository.findAll();
    }
}
